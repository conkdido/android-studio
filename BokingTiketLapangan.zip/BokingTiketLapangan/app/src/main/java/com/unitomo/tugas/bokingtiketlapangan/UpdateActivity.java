package com.unitomo.tugas.bokingtiketlapangan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.unitomo.tugas.bokingtiketlapangan.api.ApiRequestTiket;
import com.unitomo.tugas.bokingtiketlapangan.api.Retroserver;
import com.unitomo.tugas.bokingtiketlapangan.model.ResponsModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateActivity extends AppCompatActivity {
    EditText nama, email, nohp, tanggal;
    RadioGroup edt_status;
    RadioButton radioButton;
    Button btnupdate, btndelete;
    ProgressDialog pd;
    String statusnya;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_main);

        nama = findViewById(R.id.edt_nama);
        email = findViewById(R.id.edt_email);
        nohp = findViewById(R.id.edt_noHP);
        tanggal = findViewById(R.id.edt_tanggal);
        edt_status = findViewById(R.id.edt_status);
        btnupdate = findViewById(R.id.btnUpdate);
        btndelete = findViewById(R.id.btnhapus);

        Intent data = getIntent();
        final String iddata = data.getStringExtra("id");
            nama.setText(data.getStringExtra("nama"));
            email.setText(data.getStringExtra("email"));
            nohp.setText(data.getStringExtra("nohp"));
            tanggal.setText(data.getStringExtra("tanggal"));
            String status = data.getStringExtra("status");



        pd = new ProgressDialog(this);

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.setMessage("Loading Hapus ...");
                pd.setCancelable(false);
                pd.show();

                ApiRequestTiket api = Retroserver.getClient().create(ApiRequestTiket.class);
                Call<ResponsModel> del  = api.deleteData(iddata);
                del.enqueue(new Callback<ResponsModel>() {
                    @Override
                    public void onResponse(Call<ResponsModel> call, Response<ResponsModel> response) {
                        Log.d("Retro", "onResponse");
                        Toast.makeText(UpdateActivity.this, response.body().getPesan(),Toast.LENGTH_SHORT).show();
                        Intent gotampil = new Intent(UpdateActivity.this,TampilData.class);
                        startActivity(gotampil);

                    }

                    @Override
                    public void onFailure(Call<ResponsModel> call, Throwable t) {
                        pd.hide();
                        Log.d("Retro", "onFailure");
                    }
                });
            }
        });

        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.setMessage("update ....");
                pd.setCancelable(false);
                pd.show();

                int selectid = edt_status.getCheckedRadioButtonId();
                radioButton = findViewById(selectid);
                statusnya = (String) radioButton.getText();

                ApiRequestTiket api = Retroserver.getClient().create(ApiRequestTiket.class);
                Call<ResponsModel> update = api.updateData(iddata,nama.getText().toString(),email.getText().toString(),
                        nohp.getText().toString(),tanggal.getText().toString(),statusnya);
                update.enqueue(new Callback<ResponsModel>() {
                    @Override
                    public void onResponse(Call<ResponsModel> call, Response<ResponsModel> response) {
                        Log.d("Retro", "Response");
                        Toast.makeText(UpdateActivity.this,response.body().getPesan(),Toast.LENGTH_SHORT).show();
                        pd.hide();
                        Intent gotampil = new Intent(UpdateActivity.this,TampilData.class);
                        startActivity(gotampil);
                    }

                    @Override
                    public void onFailure(Call<ResponsModel> call, Throwable t) {
                        pd.hide();
                        Log.d("Retro", "OnFailure");

                    }
                });
            }
        });
    }

}
