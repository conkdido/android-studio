package com.unitomo.tugas.bokingtiketlapangan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.unitomo.tugas.bokingtiketlapangan.api.ApiRequestTiket;
import com.unitomo.tugas.bokingtiketlapangan.api.Retroserver;
import com.unitomo.tugas.bokingtiketlapangan.model.ResponsModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    EditText nama, email, nohp,tanggal;
    RadioGroup edt_status;
    RadioButton pil_status;
    Button btnsave, btnTampildata;
    ProgressDialog pd;
    private int status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nama = findViewById(R.id.edt_nama);
        email = findViewById(R.id.edt_email);
        nohp = findViewById(R.id.edt_noHP);
        tanggal = findViewById(R.id.edt_tanggal);
        edt_status = findViewById(R.id.edt_status);

        btnTampildata = findViewById(R.id.btntampildata);
        btnsave = findViewById(R.id.btn_insertdata);

        pd = new ProgressDialog(this);

        btnTampildata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent godata = new Intent(MainActivity.this, TampilData.class);
                startActivity(godata);
            }
        });


        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.setMessage("send data ... ");
                pd.setCancelable(false);
                pd.show();

                int selectid = edt_status.getCheckedRadioButtonId();
                String snama = nama.getText().toString();
                String semail = email.getText().toString();
                String snohp = nohp.getText().toString();
                String stanggal = tanggal.getText().toString();
                pil_status = findViewById(selectid);

                String statusnya = (String) pil_status.getText();


                ApiRequestTiket api = Retroserver.getClient().create(ApiRequestTiket.class);

                Call<ResponsModel> sendTiket= api.sendTiket(snama,semail,snohp,stanggal,statusnya);
                sendTiket.enqueue(new Callback<ResponsModel>() {
                    @Override
                    public void onResponse(Call<ResponsModel> call, Response<ResponsModel> response) {
                        pd.hide();
                        Log.d("RETRO", "response : " + response.body().toString());
                        String kode = response.body().getKode();

                        if(kode.equals("1"))
                        {
                            Toast.makeText(MainActivity.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                        }else
                        {
                            Toast.makeText(MainActivity.this, "Data Error tidak berhasil disimpan", Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onFailure(Call<ResponsModel> call, Throwable t) {
                        pd.hide();
                        Log.d("RETRO", "Falure : " + "Gagal Mengirim Request");
                    }
                });
            }
        });
    }
}
