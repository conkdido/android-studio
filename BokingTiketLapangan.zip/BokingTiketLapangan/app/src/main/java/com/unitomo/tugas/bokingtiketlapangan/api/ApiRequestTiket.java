package com.unitomo.tugas.bokingtiketlapangan.api;

import com.unitomo.tugas.bokingtiketlapangan.model.ResponsModel;

import java.util.Date;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;


public interface ApiRequestTiket {

    @FormUrlEncoded
    @POST("insert.php")
    Call<ResponsModel> sendTiket(@Field("nama") String nama,
                                 @Field("email") String usia,
                                 @Field("nohp") String nohp,
                                 @Field("tanggal") String tanggal,
                                 @Field("status") String status);

    @GET("read.php")
    Call<ResponsModel> getTiket();

    @FormUrlEncoded
    @POST("update.php")
    Call<ResponsModel> updateData(@Field("id") String id,
                                  @Field("nama") String nama,
                                  @Field("email") String usia,
                                  @Field("nohp") String nohp,
                                  @Field("tanggal") String tanggal,
                                  @Field("status") String status);

    @FormUrlEncoded
    @POST("delete.php")
    Call<ResponsModel> deleteData(@Field("id") String id);
}
