package com.unitomo.tugas.bokingtiketlapangan.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.unitomo.tugas.bokingtiketlapangan.MainActivity;
import com.unitomo.tugas.bokingtiketlapangan.R;
import com.unitomo.tugas.bokingtiketlapangan.UpdateActivity;
import com.unitomo.tugas.bokingtiketlapangan.model.DataModel;

import java.util.List;

public class AdapterData extends RecyclerView.Adapter<AdapterData.HolderData> {

    private List<DataModel> mList ;
    private Context ctx;


    public  AdapterData (Context ctx, List<DataModel> mList)
    {
        this.ctx = ctx;
        this.mList = mList;
    }

    @Override
    public HolderData onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.layoutlist,parent, false);
        HolderData holder = new HolderData(layout);
        return holder;
    }

    @Override
    public void onBindViewHolder(HolderData holder, int position) {
        DataModel dm = mList.get(position);
        holder.nama.setText(dm.getNama());
        holder.email.setText(dm.getEmail());
        holder.nohp.setText(dm.getNohp());
        holder.tanggal.setText(dm.getTanggal());
        holder.status.setText(dm.getStatus());
        holder.dm = dm;
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }


    class HolderData extends  RecyclerView.ViewHolder{
        TextView nama, email, nohp, tanggal,status;
        DataModel dm;
        public HolderData (View v)
        {
            super(v);

            nama  = v.findViewById(R.id.tvNama);
            email = v.findViewById(R.id.tvEmail);
            nohp = v.findViewById(R.id.tvNohp);
            tanggal = v.findViewById(R.id.tvTanggal);
            status = v.findViewById(R.id.tvStatus);

            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent goInput = new Intent(ctx,UpdateActivity.class);
                    goInput.putExtra("id", dm.getId());
                    goInput.putExtra("nama", dm.getNama());
                    goInput.putExtra("email", dm.getEmail());
                    goInput.putExtra("nohp", dm.getNohp());
                    goInput.putExtra("tanggal", dm.getTanggal());
                    goInput.putExtra("status", dm.getStatus());

                    ctx.startActivity(goInput);
                }
            });
        }
    }
}
